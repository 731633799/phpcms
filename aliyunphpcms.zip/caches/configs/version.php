<?php
return array(
'pc_version' => 'V9.6.3',	//phpcms 版本号
'pc_release' => '20170515',	//phpcms 更新日期
);
?>